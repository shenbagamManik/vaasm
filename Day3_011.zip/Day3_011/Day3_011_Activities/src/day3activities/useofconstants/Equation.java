package day3activities.useofconstants;

public class Equation implements PhysicalConstants{
	PhysicalConstants pc;
	public void energy(double mass) {
		double energy = mass * Math.pow(pc.vacuum,2);//E=MC^2
		
		System.out.println("Enercy(E=MC^2) is ="+energy);
	}
	public void newtonsLaw(double mass1,double mass2,double radious) {
		double gravitationForce = (pc.gravity_constant_G *mass1*mass2)/Math.pow(radious,2);//F = Gm1m2/r^2
		
		System.out.println("GravitationForce(F = Gm1m2/r^2)is ="+gravitationForce);
	}
	public void velocity(double time) {
		double velocity = 0.5*pc.sga_g*Math.pow(time,2);//1/2 gt^2
		
		System.out.println("Velocity(1/2 gt^2) is ="+velocity);
	}

}
