package day3activities.useofconstants;

public interface PhysicalConstants {
double vacuum =299792458;
double gravity_constant_G = 6.674*Math.pow(10,-11);
double sga_g = 9.80665;
}
