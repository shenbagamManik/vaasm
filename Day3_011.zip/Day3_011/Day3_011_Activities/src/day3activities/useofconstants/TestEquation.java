package day3activities.useofconstants;

public class TestEquation {

	public static void main(String[] args) {
		double massOfEarth = 6.0*Math.pow(10,24); 
		double massOfSun = 2.0*Math.pow(10,30); 
		double radiousOfEarth = 6.0*Math.pow(10,6); 
		
		Equation equa = new Equation();
		equa.energy(2);
		equa.newtonsLaw(massOfEarth, massOfSun, radiousOfEarth);
		equa.velocity(3);

	}

}
