package day3activities.shapes;

public interface ShapeMarkerInterface{

}
