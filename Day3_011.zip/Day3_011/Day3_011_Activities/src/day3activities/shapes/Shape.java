package day3activities.shapes;

import java.io.Serializable;

public abstract class Shape {
	double base;
	double height;
	double length;
	double weight;
	double radious;
	
	abstract void area();
	abstract double volume();
	Shape(){
		
	}
	
	public double getBase() {
		return base;
	}
	public void setBase(double base) {
		this.base = base;
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public double getLength() {
		return length;
	}
	public void setLength(double length) {
		this.length = length;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	public double getRadious() {
		return radious;
	}
	public void setRadious(double radious) {
		this.radious = radious;
	}
	
}

class Triangle extends Shape{
	Triangle(double base,double height){
		this.setHeight(height);
		this.setBase(base);
	}

	@Override
	void area() {
		
		double triArea = 0.5*(height*base);
		System.out.println("Area of triangel is ="+triArea);
	}

	@Override
	double volume() {
		
		return -1;
	}
	
}
class Rectangle extends Shape {
	Rectangle(double length,double width){
		this.setLength(length);
		this.setWeight(width);
	}

	@Override
	void area() {
		
		double rectArea = length * weight;
		System.out.println("Area of Rectangle is ="+rectArea);
	}

	@Override
	double volume() {
		
		return -1;
	}
	
}
class Sphere extends Shape implements ShapeMarkerInterface{
	
	Sphere(double radious){
		this.setRadious(radious);
	}

	@Override
	void area() {
		
		double areSphere = 4*3.143*Math.pow(radious, 2);
		System.out.println("Area of Sphere is ="+areSphere);
	}

	@Override
	double volume() {
		
		double volSphere = (4/3)*3.143*Math.pow(radious, 3);
		System.out.println("Volume of Sphere is ="+volSphere);
		return 0;
		
		
	}
	
}
class Cube extends Shape implements ShapeMarkerInterface{
	
	Cube(double llength,double wwidth,double hheight){
		this.setLength(llength);
		this.setHeight(hheight);
		this.setWeight(wwidth);		
	}

	@Override
	void area() {
		
		double areaCube = (2*length*weight)*(2*length*height)*(2*weight*height);
		System.out.println("Area of Cube is ="+areaCube);
	}

	@Override
	double volume() {
		
		double volCube = length*height*weight;
		System.out.println("Volume of Cube is ="+volCube);
		return 0;
		
		
	}
	
}
