package day3activities.shapes;

public class TestShape {

	public static void main(String[] args) {
		Shape s1[] = new Shape[5];
		s1[0] = new Triangle(10,12.5);
		s1[1] = new Rectangle(15.6,45.2);
		s1[2] = new Sphere(60.5);
		s1[3] = new Cube(70.3,30.2,25.1);
		s1[4] = new Rectangle(50,80);
		
		for(int i=0;i<5;i++) {
			s1[i].area();
			s1[i].volume();
		}
	}

}
