package day3activities.testpack;

import day3activities.calculatorpack.Calculator;

public class TestCalculator {

	public static void main(String[] args) {
		Calculator calc = new Calculator();
		double addition = calc.add(56,100);
		System.out.println("Addition="+addition);
		double subtraction =calc.subract(700,500);
		System.out.println("Subraction="+subtraction);
		double multi =calc.multiply(700,500);
		System.out.println("Multiplication="+multi);
		double division =calc.divide(700,500);
		System.out.println("Divition="+division);
		
		
	}

}
