package day3activities.calculatorpack;

public class Calculator {

	public double add(float num1,float num2) {
		double result = num1+num2;
		return result;
	}
	public double subract(float num1,float num2) {
		return num1-num2;
	}
	public double multiply(float num1,float num2) {
		return num1*num2;
	}
	public double divide(float num1,float num2) {
		return num1/num2;
	}	
}
