package day3activities.vehicle;

public class Vehicle {
	String colour;
	int noTyre;
	String model;
	Vehicle(String colour,int noTyre,String model){
		this.colour = colour;
		this.noTyre = noTyre;
		this.model = model;
	}
	public void display() {
		
	}
	
}
class Truck extends Vehicle{
	String name = "ABC truck";
	Truck(String colour, int noTyre, String model) {
		super(colour, noTyre, model);
		// TODO Auto-generated constructor stub
	}
	public void display() {
		System.out.println("Truck Name:"+name);
		System.out.println("Truck Colour:"+colour);
		System.out.println("Truck No of Tyres:"+noTyre);
		System.out.println("Truck Model:"+model);
	}
}
class Bus extends Vehicle{
	String name = "TNPC bus";
	Bus(String colour, int noTyre, String model) {
		super(colour, noTyre, model);
		// TODO Auto-generated constructor stub
	}
	public void display() {
		System.out.println("Bus Name:"+name);
		System.out.println("Bus Colour:"+colour);
		System.out.println("Bus No of Tyres:"+noTyre);
		System.out.println("Bus Model:"+model);
	}
	
}
class Car extends Vehicle{
	String name = "Honda Activa";
	Car(String colour, int noTyre, String model) {
		super(colour, noTyre, model);
		// TODO Auto-generated constructor stub
	}
	public void display() {
		System.out.println("Car Name:"+name);
		System.out.println("Car Colour:"+colour);
		System.out.println("Car No of Tyres:"+noTyre);
		System.out.println("Car Model:"+model);
	}
	
}
