package day3activities.vehicle;

public class Road {

	public static void main(String[] args) {
		Vehicle v1 = new Truck("Yellow",22,"Trailer");
		v1.display();
		Vehicle v2 = new Bus("Brown",6,"Duplex");
		v2.display();
		Vehicle v3 = new Truck("Golden matalic",4,"vx");
		v3.display();

	}

}
