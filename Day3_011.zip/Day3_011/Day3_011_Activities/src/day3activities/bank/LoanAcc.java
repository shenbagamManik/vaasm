package day3activities.bank;

public interface LoanAcc {

}
