package day3activities.bank;

public interface DepositAcc {

}
