package day11activities;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class WelomeServlet
 */
@WebServlet(
		urlPatterns = { "/WelomeServlet" }, 
		initParams = { 
				@WebInitParam(name = "visitcount", value = "0"),
				@WebInitParam(name = "visitcount", value = "1")
		})
public class WelomeServlet extends HttpServlet {
	private int visitCount;
	public void init()  {
		visitCount = 0;
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Entered to welcome servlet");
		response.setContentType("text/html");
		ServletContext context = getServletContext();
		visitCount++;
		
		String str = context.getInitParameter("visitcount");
		PrintWriter pw = response.getWriter();
		//pw.println(context.getInitParameter("visitcount"));	
		
		pw.print("<h1>Number of visits to this site:"+visitCount+"</h1>");
		
		pw.println("<form method=\"post\" action=\"login.html\">");
		pw.println("<input type=\"submit\" value=\"Submit\">");
		pw.println("</form>");
	}
}
