package day11activities;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Enumeration;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Servlet implementation class LoginConfigServlet
 */
@WebServlet(
		urlPatterns = { "/LoginConfigServlet" }, 
		initParams = { 
				@WebInitParam(name = "name", value = "shen", description = "shen"), 
				@WebInitParam(name = "phoneno", value = "9884472620"), 
				@WebInitParam(name = "dateofbirth", value = "01-05-1984")
		})
public class LoginConfigServlet extends HttpServlet {
	DataSource ds = getDataSource();
	private int visitCount;
	public void init()  {
		visitCount = 0;
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String inUser = request.getParameter("userName");
		String inPass = request.getParameter("passWord");
		
		response.setContentType("text/html");
		visitCount++;
		System.out.println("number of visits"+visitCount);
		ServletConfig sc = getServletConfig();
		Enumeration<String> e= sc.getInitParameterNames();
		String str;
		
		PrintWriter pw = response.getWriter();
		Connection con;
		try {
			con = ds.getConnection();
		
			PreparedStatement pstat = con.prepareStatement("select * from admintbl where username=? and password=?");
			pstat.setString(1,inUser);
			pstat.setString(2,inPass);
			ResultSet rs=pstat.executeQuery();
			System.out.println("select * from users");
			if(rs.next()) {
				while(e.hasMoreElements()) {
					str = e.nextElement();
					pw.println("<br>Param name:<h5 style=\"color:blue\">"+ str+"</h5>");
					//System.out.println("<br>Param name:<h5 style=\"color:blue\""+ str+"></h5>");
					pw.println("value:<h5 style=\"color:blue\">"+sc.getInitParameter(str)+"</h5>");
				}
			}else {
				pw.print("<h1 style=\"color:red\">Please Login as admin user</h1>");
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
 	}
	public DataSource getDataSource(){
		Context ctx = null;
		DataSource ds = null;
		try {
			ctx = new InitialContext();
			ds = (DataSource) ctx.lookup("java:/comp/env/jdbc/myoracle");
			
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return ds;
	}
}
