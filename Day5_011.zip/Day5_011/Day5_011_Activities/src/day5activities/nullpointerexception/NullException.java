package day5activities.nullpointerexception;

public class NullException {

}
