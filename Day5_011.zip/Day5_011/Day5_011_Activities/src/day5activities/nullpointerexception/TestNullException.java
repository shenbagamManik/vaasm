package day5activities.nullpointerexception;

public class TestNullException {

	public static void main(String[] args){
		String a[] = null;
		try {
		System.out.println(a.length);
		System.out.println(a[0]);
		int num = Integer.parseInt("shen");
		}catch(Exception e) {
			System.out.println("Null pointer exception:: "+e);
		}
	}

}
