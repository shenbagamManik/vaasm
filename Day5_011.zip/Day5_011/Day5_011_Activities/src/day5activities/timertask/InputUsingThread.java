package day5activities.timertask;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;

public class InputUsingThread{
	String str ="";
	TimerTask tt = new TimerTask() {
	@Override
	public void run() {
		if(str.equals("")) {
			System.out.println("Better Luck Next time..");
			System.exit(0);
		}
		
	}
	};

	String getInput() {
		Timer time = new Timer();
		time.schedule(tt,60*1000);		
		
		System.out.println("Enter your lucky number in 1 min...");
		Scanner s = new Scanner(System.in);
		str = s.nextLine();
		time.cancel();
		System.out.println("Congratulation!");
		
		return null;		
	}
}
