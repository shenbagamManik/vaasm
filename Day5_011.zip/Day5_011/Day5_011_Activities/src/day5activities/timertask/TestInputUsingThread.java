package day5activities.timertask;

public class TestInputUsingThread {

	public static void main(String[] args) throws InterruptedException {
		
		(new InputUsingThread()).getInput();	

	}

}

