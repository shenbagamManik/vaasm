package day5activities.numberformateexception;

public class TestNumericException {

	public static void main(String args[]) {
		NumberFormateException nfe = new NumberFormateException("Shen");
		nfe.checkNumericException();
	}
}
