package day5activities.numberformateexception;

public class NumberFormateException {
	
		String str;
		NumberFormateException(String str){
			this.str=str;
		}	

		public String getStr() {
			return str;
		}

		public void setStr(String str) {
			this.str = str;
		}
		
		 void checkNumericException() {
			try {
				int num = Integer.parseInt(str);
			}catch(NumberFormatException nfe) {
					System.out.println("Number format exception occurred::"+nfe);
			}
		}

}
