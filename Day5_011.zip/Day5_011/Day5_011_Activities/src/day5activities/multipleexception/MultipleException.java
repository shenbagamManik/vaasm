package day5activities.multipleexception;

public class MultipleException {
	
		String a[] = null;
		Integer num[] = new Integer[10];
		void checkException() {
		//ClassNotFoundException
		try {
			Class DummyClass  = Class.forName("day5activities.nullpointerexception.NullExceptionList");
			System.out.println("Class "+DummyClass+" loaded successfully!");		
			
		}catch(ClassNotFoundException e) {
			System.out.println("DummyClass throws "+e);
		}
		//CloneNotSupportedException
		try {
			UseClone uc = new UseClone();
			uc.a = 100;
			uc.b = 200;
			
			UseClone uc1 = (UseClone)uc.clone();
			uc1.a = 400;
			uc1.b = 500;
			System.out.println("Mainclass variables::"+uc.a+","+uc.b+"\nClone class variables::"+uc1.a+","+uc1.b);
		
		}catch(CloneNotSupportedException clone) {
			System.out.println(" Exception thrown when not implement the Cloneable interface. "+clone);
		}
		//ClassCastException
		try {
			ClassCastExce cce = new ClassCastExce();
			Addition add = new Addition();			
			add = (Addition) cce;
		}catch(ClassCastException e) {
			System.out.println("Class cast exception "+e);
		}
		//NumberFormateException
		try {
			num[7]=Integer.parseInt("the");
		}catch(Exception e) {
			System.out.println("NumberFormateException:: "+e);
		}
		//NegativeArraySizeException
		try {
			String t[] = new String[-3];
		}catch(NegativeArraySizeException e) {
			System.out.println("If the size of array is nagative then :::  "+e);
		}
		//Null pointer exception
		try {
			Integer t[] = null;
			
			int x = t[2];
		}catch(NullPointerException e) {
			System.out.println("NullPointerException:::  "+e);
		}
		
		}
}
