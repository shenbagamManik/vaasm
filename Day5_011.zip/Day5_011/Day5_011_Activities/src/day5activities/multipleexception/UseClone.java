package day5activities.multipleexception;

public class UseClone {
	int a;
    int b;
    
    public Object clone() throws  CloneNotSupportedException
    {
        return super.clone();
    }
}