package day5activities.multipleexception;

public class TestException {

	public static void main(String[] args) {
		MultipleException me = new MultipleException();
		me.checkException();
	}

}
