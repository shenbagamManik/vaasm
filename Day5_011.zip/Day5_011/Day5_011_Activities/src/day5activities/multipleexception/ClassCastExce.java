package day5activities.multipleexception;

public class ClassCastExce {
		void sumFun() {			
			int add = 100+200;
		}
}
class Addition extends ClassCastExce {
	void sumFun() {			
		int add = 100+200;
	}
}
