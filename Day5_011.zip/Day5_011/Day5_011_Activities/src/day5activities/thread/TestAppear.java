package day5activities.thread;

public class TestAppear {

	public static void main(String[] args) throws InterruptedException {
		Thread t =new Thread(new Appear());
		 t.start();		
	}

}
