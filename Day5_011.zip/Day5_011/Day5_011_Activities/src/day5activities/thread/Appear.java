package day5activities.thread;

public class Appear implements Runnable{
	 char c[]={'H','E','L','L','O','W'};
	 public void run() {
		 int i=0;
		 while (i<5){
			 
			 try {
				Thread.sleep(1000);
				System.out.print(c[i++]);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 }
	}
}
