package day5activities.multithread;

public class TollVehicles implements Runnable{
	@Override
	public void run() {
		
		for(int i=1;i<=5;i++) {
			try {
				Thread.sleep(5000);
				synchronized(this) {
				System.out.println("Toll vehicle "+i+" crossing now");
				}
			} catch (InterruptedException e) {				
				e.printStackTrace();
			}
		}
	}
}
