package day5activities.multithread;

public class BridgeVehicles implements Runnable{

	@Override
	public void run() {
		
		for(int i=1;i<=5;i++) {
			try {
				Thread.sleep(2000);
				System.out.println("Bridge vehicle "+i+" crossing now");
			} catch (InterruptedException e) {				
				e.printStackTrace();
			}
		}
	}
	

}
