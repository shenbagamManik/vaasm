package day5activities.multithread;

public class TestEntry {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread t1 = new Thread(new BridgeVehicles());
		Thread t2 = new Thread(new TollVehicles());
		t2.start();
		t1.start();
	}

}
