package day12activities;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;


//@WebServlet("/DataSourceServlet")
public class DataSourceServlet extends HttpServlet {
	String dbUser;
	String dbPass;
	String inUser;
	String inPass;
	
	DataSource ds = getDataSource();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		inUser = request.getParameter("userName");
		inPass = request.getParameter("passWord");
		PrintWriter pwrit;
		Connection con = null;
		Statement pstat = null;
		try {
			pwrit = response.getWriter();
			con = ds.getConnection();
			pstat = con.createStatement();
			ResultSet rs=pstat.executeQuery("select * from users");
			//System.out.println("select * from oraUser");
			System.out.println(rs.next());
			System.out.println(rs.getString(1));
			System.out.println(rs.getString(2));
			dbUser = rs.getString(1);
			dbPass = rs.getString(2);
			if(inUser.equals(dbUser)&& inPass.equals(dbPass)){
				RequestDispatcher reqdis = request.getRequestDispatcher("Welcome");
				reqdis.include(request, response);
				HttpSession session = request.getSession();
				session.setAttribute("userName",inUser);
				
			}else{
				pwrit.print("<h1 style=\"color:red\">Failure</h1>");
			}	
			//Using prepared statement
			
			/*pstat = con.prepareStatement("select * from users where username=? and password=?");
			pstat.setString(1,inUser);
			pstat.setString(2,inPass);
			ResultSet rs=pstat.executeQuery();
			System.out.println(rs.next());*/
			//System.out.println(rs.getString(1));
		} catch (SQLException e) {			
			e.printStackTrace();
		}
	}
	
	
	public DataSource getDataSource(){
		Context ctx = null;
		DataSource ds = null;
		try {
			ctx = new InitialContext();
			ds = (DataSource) ctx.lookup("java:/comp/env/jdbc/myoracle");
			
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return ds;
	}
    
	

}
