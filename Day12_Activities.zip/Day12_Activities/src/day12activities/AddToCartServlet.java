package day12activities;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class AddToCartServlet
 */
@WebServlet("/AddToCartServlet")
public class AddToCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		try{
			String music[] = request.getParameterValues("music");
			String book[] = request.getParameterValues("book");
			HttpSession session = request.getSession();		
			session.setAttribute("cart", new ArrayList<Object>());
			//ArrayList<Object> cart = new ArrayList<Object>();
			
			ArrayList<Object> cart = (ArrayList<Object>) session.getAttribute("cart");
			
			
			if(music != null)
				for(int i=0;i<music.length;i++){ 
					cart.add(music[i]);
					System.out.println(music[i]);
				}
			if(book != null)
				for(int i=0;i<book.length;i++){ 
				cart.add(book[i]);
				System.out.println(music[i]);
				}
			
			
			session.setAttribute("cart",cart);
			
			
			
			pw.println("Add to the cart<br>");
			pw.println("<A href='ShowServlet?flag=n'>Show Cart</a><br>");
			pw.println("<A href='book.html'>Books</a><br>");
			pw.println("<A href='music.html'>Musics</a><br>");
			
		}catch(Exception e){
			pw.print(e);
		}
		
		finally{
			pw.close();
		}
	}

}
