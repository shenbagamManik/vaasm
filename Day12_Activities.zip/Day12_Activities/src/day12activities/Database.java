package day12activities;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Database {
	private Connection conn = null;

	Database(String dataBase,String userName,String passWord){
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			System.out.println(dataBase+"\t"+userName+"\t"+passWord);
			//this.conn = DriverManager.getConnection("jdbc:oracle:thin:hr/hr@localhost:1521:xe");
			this.conn = DriverManager.getConnection(dataBase, userName, passWord);
			System.out.println("Connection established!!");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public Connection getConnection() {
		return this.conn;
	}

	/*public ResultSet runSql(String sql) throws SQLException {
		System.out.println("query" + sql);
		java.sql.Statement sta = conn.createStatement();
		ResultSet rs = sta.executeQuery(sql);
		return sta.executeQuery(sql);
	}*/
}
