package day12activities;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TestListenerServlet
 */
//@WebServlet("/TestListenerServlet")
public class TestListenerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType("text/html");
		Database db = (Database) getServletContext().getAttribute("db");
		Connection con = db.getConnection();
		PrintWriter pw = response.getWriter();
		pw.println("Connection Established!!");
		
		
		/*try {
			Statement stat = con.createStatement();
			PrintWriter pw = response.getWriter();
			String sql = "select * from users";
			System.out.println(sql);
			ResultSet rs = stat.executeQuery(sql);
			while(rs.next()){
				pw.println(rs.getString("username"));
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}*/
		
		
	}

}
