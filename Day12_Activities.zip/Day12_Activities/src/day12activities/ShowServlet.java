package day12activities;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ShowServlet
 */
@WebServlet("/ShowServlet")
public class ShowServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		pw.print("Entered to show servlet");
		try{
			pw.print("<html><body><br>");
			HttpSession session = request.getSession();
			ArrayList<Object> cart = (ArrayList<Object>) session.getAttribute("cart");
			System.out.println(cart.size());
			for(int i=0;i<cart.size();i++){
				pw.println(i+". "+cart.get(i)+"<br>");
			}
			
			String flag = request.getParameter("flag");
			if(flag.equals("Y"))
				session.invalidate();
			pw.print("<a href=index.html>Home</a>");
			pw.print("</body></html>");
		}catch(Exception e){
			pw.print("<html><body><br>");
			pw.print(e);
			pw.print("</body></html>");
		}
		finally{
			pw.close();
		}
	}

}
