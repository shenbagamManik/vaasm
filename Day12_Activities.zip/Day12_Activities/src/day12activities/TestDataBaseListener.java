package day12activities;

import java.io.IOException;

import javax.servlet.AsyncEvent;
import javax.servlet.AsyncListener;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextAttributeEvent;
import javax.servlet.ServletContextAttributeListener;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.ServletRequestAttributeEvent;
import javax.servlet.ServletRequestAttributeListener;
import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionActivationListener;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;
import javax.servlet.http.HttpSessionEvent;
//import javax.servlet.http.HttpSessionIdListener;
import javax.servlet.http.HttpSessionListener;

@WebListener
public class TestDataBaseListener implements ServletContextListener{

	public void contextInitialized(ServletContextEvent arg0)  { 
		ServletContext sc = arg0.getServletContext();
		
		String url = sc.getInitParameter("url");
		String userName = sc.getInitParameter("user_name");
		String passWord = sc.getInitParameter("password");
		String database = sc.getInitParameter("database");
		System.out.println("url,user, pass"+url+userName+passWord);
		
		Database db = new Database(url, userName, passWord);
		sc.setAttribute("db", db);
	}

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		// TODO Auto-generated method stub
		
	}
   	
	
}
