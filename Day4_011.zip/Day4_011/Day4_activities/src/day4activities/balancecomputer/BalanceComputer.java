package day4activities.balancecomputer;

public abstract class BalanceComputer{
	static String typeAccount;
	double balance;
	double pricipal;
	double intRate;
	public static String getTypeAccount() {
		return typeAccount;
	}

	public static void setTypeAccount(String typeAccount) {
		BalanceComputer.typeAccount = typeAccount;
	}

	public double getPricipal() {
		return pricipal;
	}

	public void setPricipal(double pricipal) {
		this.pricipal = pricipal;
	}

	public double getIntRate() {
		return intRate;
	}

	public void setIntRate(double intRate) {
		this.intRate = intRate;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	BalanceComputer(){	
		this.pricipal = this.getPricipal();
		this.intRate = this.getIntRate();
	}
	
	public static BalanceComputer getBalanceComputer(char accType){	
		BalanceComputer bc = null;
		
		if(accType == 'c'){
			bc = new BalanceComputer(){
				
				@Override
				double getBalance() {					
					balance = pricipal+(pricipal*intRate*5);
					return balance;					
				}
				
			};

		}
		if(accType == 's'){
			bc = new BalanceComputer(){
				
				@Override
				double getBalance() {					
					balance = pricipal*(1+intRate/4);					
					return balance;					
				}
				
			};

		}
		return bc;
	}
	abstract double getBalance();	
	
}
