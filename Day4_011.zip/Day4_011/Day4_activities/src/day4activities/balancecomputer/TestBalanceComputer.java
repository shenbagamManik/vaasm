package day4activities.balancecomputer;

public class TestBalanceComputer {

	public static void main(String[] args) {
		char c = 'c';
		char s = 's';
		BalanceComputer bc = BalanceComputer.getBalanceComputer(c);
		bc.setPricipal(100000);
		bc.setIntRate(6.55);
		
		//BalanceComputer.getBalanceComputer(c );
		System.out.println(bc.getBalance());

	}

}
