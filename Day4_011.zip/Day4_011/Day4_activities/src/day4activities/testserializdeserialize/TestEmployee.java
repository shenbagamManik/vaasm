package day4activities.testserializdeserialize;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class TestEmployee {

	public static void main(String[] args) {
		Employee emp = new Employee();
		emp.setEmp_id(1001);
		emp.setEmp_name("Shenbagam");
		emp.setEmp_sal(600000);
		//Serialization
		try{
			FileOutputStream fos = new FileOutputStream("../Batch/Batch.txt");
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			
			oos.writeObject(emp);
			
			oos.close();
			fos.close();
			System.out.println("The object has serialized");
		}catch(Exception e){
			
		}
		//Deserialization
		Employee emp1 = null;
		try{
			FileInputStream fis = new FileInputStream("../Batch/Batch.txt");
			ObjectInputStream ois = new ObjectInputStream(fis);
			
			emp1 = (Employee)ois.readObject();
			
			ois.close();
			fis.close();
			System.out.println("The object has Deserialized");
			System.out.println("Employee Id::"+emp1.getEmp_id());
			System.out.println("Employee Name::"+emp1.getEmp_name());
			System.out.println("Employee Salary::"+emp1.getEmp_sal());
			
		}catch(Exception e){
			
		}
	}

}
