package day4activities.addressbook;

public class TestAddressBook {
	public static void main(String args[]){
		AddressBook ab = new AddressBook();
		AddressBook.Address nestedObject = new AddressBook.Address();
		ab.setName("Shenbagam");
		ab.setEmailId("shen@hcl.com");		
		nestedObject.houseAddress();
		
	}
}
