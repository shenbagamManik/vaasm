package day4activities.addressbook;

public class AddressBook {

	static String name;
	private String tempaddress;
	static String premAdd;
	private long phoneNum;
	static String emailId;
	AddressBook(){
		Address ad = new Address();
	}
	
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTempaddress() {
		return tempaddress;
	}
	public void setTempaddress(String tempaddress) {
		this.tempaddress = tempaddress;
	}
	public String getPremAdd() {
		return premAdd;
	}
	public void setPremAdd(String premAdd) {
		this.premAdd = premAdd;
	}
	public long getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(long phoneNum) {
		this.phoneNum = phoneNum;
	}
	static class Address{
		 private String name;
		 String streetAdd;
		 String city;
		 String state;

		void houseAddress(){
			AddressBook ab = new AddressBook();
			name = ab.getName();
			streetAdd = "1st,nehru street";
		    city= "Chennai";
			state = "TamilNadu";			
			
			this.name = ab.getName();
			//streetAdd = ab.getPremAdd();
			
			System.out.println("Name::"+name);
			System.out.println("Address::"+streetAdd+","+city+","+state);
			System.out.print("Mail id::"+emailId);
			
		}
	}
	
}
