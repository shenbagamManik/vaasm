package day4activities.filecreation;
import java.io.*;
public class CreateFile {
	void createFile() throws IOException{	
		String batFolder = "../Batch";
		String batFile = "../Batch/BatchFile.txt";
		new File(batFolder).mkdir();
		File batFileFolder = new File("../");
		System.out.println(batFileFolder.getAbsolutePath());
		File[] listOfFiles = batFileFolder.listFiles();
		File batchFile = new File(batFile);
		
		if(batchFile.createNewFile()){
			System.out.println("File is create!");
		}else{
			System.out.println("File exists");
		}
		FileWriter writer = new FileWriter(batchFile);
		writer.write("Test data");
		writer.close();
		
		for (int i = 0; i < listOfFiles.length; i++) {
		      if (listOfFiles[i].isFile()) {
		        System.out.println("File " + listOfFiles[i].getName());
		      } else if (listOfFiles[i].isDirectory()) {
		        System.out.println("Directory " + listOfFiles[i].getName());
		      }
		    }
		
	}
}
