package day4activities.filecreation;

import java.io.IOException;

public class TestCreateFile {

	public static void main(String[] args) throws IOException {
		CreateFile cf = new CreateFile();
		cf.createFile();

	}

}
