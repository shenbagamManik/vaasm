package day7activities.collections.vector;

public class HeadOfDepartment {
	String name;
	Integer id;
	String department;
	String qualification;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	void display() {
		/*System.out.println("Name::"+this.name);
		System.out.println("ID::"+this.id);
		System.out.println("Department::"+this.department);*/
		String convert = "HOD"+id.toString();
		System.out.println("Head of Department Id number is::"+convert);
	}
}
