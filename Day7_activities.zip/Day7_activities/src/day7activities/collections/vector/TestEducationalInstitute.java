package day7activities.collections.vector;

import java.util.ListIterator;
import java.util.Vector;

public class TestEducationalInstitute {

	public static void main(String[] args) {
		
		Student stud = new Student();
		Teacher tech = new Teacher();
		HeadOfDepartment hod = new HeadOfDepartment();
		System.out.println("Implementation of toString() method");
		System.out.println("-----------------------------------");
		stud.setId(1002);
		stud.display();
		tech.setId(203);
		tech.display();
		hod.setId(101);
		hod.display();
		System.out.println("\nName of object's classes are displayed");
		System.out.println("--------------------------------------");
		Vector<Object> vec = new Vector<Object>();
			vec.add(stud);
			vec.add(tech);
			vec.add(hod);
		ListIterator listIte = vec.listIterator();
		while(listIte.hasNext()) {			
			System.out.println(listIte.next().getClass().getSimpleName());
		}
	}

}
