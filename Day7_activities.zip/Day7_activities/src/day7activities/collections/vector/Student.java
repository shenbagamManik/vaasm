package day7activities.collections.vector;

public class Student {
	String name;
	Integer id;	
	String department;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	void display() {
		/*System.out.println("Name::"+this.name);
		System.out.println("ID::"+this.id);
		System.out.println("Department::"+this.department);*/
		String convert = "MBA"+id.toString();
		System.out.println("Student Id number is::"+convert);
	}
	
}
