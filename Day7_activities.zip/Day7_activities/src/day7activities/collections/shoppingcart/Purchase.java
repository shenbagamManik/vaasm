package day7activities.collections.shoppingcart;

import java.util.HashMap;
import java.util.Map;

public class Purchase extends Product{
	Product p =new Product();
	int quantity;
	String value;
	static Map<Integer,String> hmPurchase = new HashMap<Integer,String>();
	Purchase(){
		
	}
	
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	void purchase(int proCode,int proQuantity) {
		
		if(p.hmProduct.containsKey(proCode)) {
			value = p.hmProduct.get(proCode)+" "+proQuantity;
			
		}
		hmPurchase.put(proCode,value);
		
	}
}
