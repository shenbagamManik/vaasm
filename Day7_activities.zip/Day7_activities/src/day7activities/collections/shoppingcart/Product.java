package day7activities.collections.shoppingcart;

import java.util.HashMap;
import java.util.Map;

public class Product {
	int pCode;
	String pName;
	double pPrice;
	String pType;
	String mesureValue;
	static Map<Integer,String> hmProduct = new HashMap<Integer,String>();
	public String getpType() {
		return pType;
	}
	public void setpType(String pType) {
		this.pType = pType;
	}

	
	public int getpCode() {
		return pCode;
	}
	public void setpCode(int pCode) {
		this.pCode = pCode;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public double getpPrice() {
		return pPrice;
	}
	public void setpPrice(double pPrice) {
		this.pPrice = pPrice;
	}
	public String getMesureValue() {
		return mesureValue;
	}
	public void setMesureValue(String mesureValue) {
		this.mesureValue = mesureValue;
	}
	
	void storeProduct() {
		String value = pName+" "+pPrice+" "+mesureValue;
		this.hmProduct.put(this.pCode,value);
	}
	

}
