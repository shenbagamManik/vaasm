package day7activities.collections.shoppingcart;

import java.util.Map;
import java.util.StringTokenizer;

public class BillGeneration extends Purchase{
	Purchase pur = new Purchase();
	Map<Integer,String> hmBill;
	
	
	String pName;
	String[] mainStr;
	int pCode;
	double pPrice;
	double totPrice;
	String mv;	
	int quantity;
	double grossTot;
	BillGeneration(){
		hmBill = pur.hmPurchase;
		mainStr = new String[4];
	}
	void generateBill() {
		System.out.println("Inside bill"+hmBill);
		System.out.println("*************Bill of product"+pName+"********************");
		System.out.println("-------------------------------------------");
		System.out.println("Product code\tDescription\tQuantity\tunit Price\ttotal Price");
		for(Map.Entry<Integer,String>entry:hmBill.entrySet()) {
			pCode = entry.getKey();			
			mainStr = entry.getValue().split(" ", 5);
			for(int i=0;i<mainStr.length;i++) {
			//	System.out.println(mainStr[i]);
				pName = mainStr[0];
				pPrice = Double.parseDouble(mainStr[1]);
				mv = mainStr[2];
				quantity = Integer.parseInt(mainStr[3]);
				
				totPrice = pPrice *quantity;
				
			}
			
			System.out.println("   "+pCode+"   \t"+pName+"       \t "+quantity+mv+"     \t "+pPrice+"      \t"+totPrice);
			grossTot = grossTot+totPrice;
			/*System.out.println("Product Description:       "+pName);
			System.out.println("Product Quantity:          "+quantity+mv);
			System.out.println("Product unit Price         "+pPrice);
			System.out.println("Product total Price        "+totPrice);*/
			
		}
		System.out.println("Gross total:"+grossTot);
	}
	
}
