package day7activities.collections.shoppingcart;

public class TestShoppingCart {

	public static void main(String[] args) {
		Product pro = new Product();
		//List of product
		for(int i=0;i<5;i++) {
			switch(i) {
			case 0:pro.setpCode(101);
				pro.setpName("SurfExcel");
				pro.setpType("Washing powder");
				pro.setpPrice(205);
				pro.setMesureValue("kg");
				pro.storeProduct();
			case 1:pro.setpCode(102);
				pro.setpName("Banana");
				pro.setpType("Food");
				pro.setpPrice(200);
				pro.setMesureValue("dozen");
				pro.storeProduct();
			case 2:pro.setpCode(103);
				pro.setpName("Egg");
				pro.setpType("food");
				pro.setpPrice(105);
				pro.setMesureValue("dozen");
				pro.storeProduct();
			case 3:pro.setpCode(104);
				pro.setpName("Rice");
				pro.setpType("Food");
				pro.setpPrice(90);
				pro.setMesureValue("kg");
				pro.storeProduct();
			case 4:pro.setpCode(105);
				pro.setpName("Carrot");
				pro.setpType("Food");
				pro.setpPrice(85);
				pro.setMesureValue("kg");
				pro.storeProduct();
			}
		}
		//System.out.println(pro.hmProduct);
		
		//Purchase order by Customer
		Purchase pur = new Purchase();
		pur.purchase(102,2);
		pur.purchase(105,1);
		pur.purchase(103,3);
		pur.purchase(101,5);
		
		//Bill for the product
		BillGeneration bg = new BillGeneration();
		bg.generateBill();
	}

}
