package day7activities.collections.teledirectory;

import java.util.HashMap;
import java.util.Map;

public class TelephoneDirectory {
	String name;
	long phoneNo;
	HashMap<String, String> hashMap = new HashMap<String,String>();
	public Map getHashMap() {
		return hashMap;
	}
	public void setHashMap(Map hashMap) {
		this.hashMap = (HashMap<String, String>) hashMap;
	}
	void add(String name,String number) {
		this.hashMap.put(number, name);
	}
	void delete(String number) {
		if(this.hashMap.containsKey(number)) {
			this.hashMap.remove(number);
		}
	}
	void search(String number) {
		if(this.hashMap.containsKey(number)) {
			System.out.println("\nSearch "+number);
			System.out.println("---------------------------------------------------------------------------");
			System.out.println("Telephone directory has the number "+number+" of name "+hashMap.get(number));
		}
		else {
			System.out.println("\nSearch "+number);
			System.out.println("---------------------------------------------------------------------------");

			System.out.println("Number not present in directory!");
		}
		
			
	}

}
