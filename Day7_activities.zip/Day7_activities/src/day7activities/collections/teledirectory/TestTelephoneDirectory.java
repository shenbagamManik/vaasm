package day7activities.collections.teledirectory;

import java.util.HashMap;
import java.util.Map;

public class TestTelephoneDirectory {

	public static void main(String[] args) {
		TelephoneDirectory td = new TelephoneDirectory();
		Map<String,String> hm = new HashMap<String,String>();
		hm.put("9884472620", "Shenbagam");
		hm.put("9884412345", "Manikandan");
		hm.put("9884476891", "Radha");
		hm.put("9884472622", "Aarthan");
		hm.put("9884472399", "Prashanth");
		
		System.out.println("Name,PhoneNumber");
		System.out.println("----------------");
		for(Map.Entry<String,String>entry:hm.entrySet()) {
			String pnum = entry.getKey();
			String name = entry.getValue();
			System.out.println(name+","+pnum);
		}
		
		td.setHashMap(hm);
		//Add one record
		td.add("Krishna", "765843215");
		System.out.println("Directory after adding a record \"Krishna\", \"765843215\"");
		System.out.println("-------------------------------");
		for(Map.Entry<String,String>entry:hm.entrySet()) {
			String pnum = entry.getKey();
			String name = entry.getValue();
			System.out.println(name+","+pnum);
		}
		//Delete one record
		td.delete("9884476891");
		System.out.println("Directory after deleting a record (\"9884476891\"");
		System.out.println("-------------------------------");
		for(Map.Entry<String,String>entry:hm.entrySet()) {
			String pnum = entry.getKey();
			String name = entry.getValue();
			System.out.println(name+","+pnum);
		}
		td.search("9884472620");
		td.search("1234567891");
	}

}
