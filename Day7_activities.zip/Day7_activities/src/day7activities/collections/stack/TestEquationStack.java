package day7activities.collections.stack;

public class TestEquationStack {

	public static void main(String[] args) {
		EquationStack es = new EquationStack();
		int express1 = es.evaluate("( ( 2 + 3 ) * 8 + 5 + 3 ) * 6");
		int express2 = es.evaluate("100 * ( 2 + 12 ) / 14");
		System.out.println(express1);
		System.out.println(express2);
	}

}
