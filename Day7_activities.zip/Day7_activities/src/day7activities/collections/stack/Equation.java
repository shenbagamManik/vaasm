package day7activities.collections.stack;

public class Equation {

}
