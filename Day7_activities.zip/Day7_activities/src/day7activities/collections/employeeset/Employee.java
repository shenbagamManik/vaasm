package day7activities.collections.employeeset;

import java.util.Hashtable;
import java.util.Set;
import java.util.TreeSet;

public class Employee {
	Integer empId;
	String name;
	long salary;
	Hashtable ht = new Hashtable();

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getSalary() {
		return salary;
	}

	public void setSalary(long salary) {
		this.salary = salary;
	}

	
	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	void saveEmpDetails() {
		String value = name+" "+salary;
		this.ht.put(this.empId,value);
	}

}
