package day7activities.collections.employeeset;

import java.util.List;
import java.util.Arrays;
import java.util.TreeSet;

public class TestEmployee {

	public static void main(String[] args) {
		Employee emp = new Employee();
		
		for(int i=0;i<10;i++) {
			switch(i) {
			case 0:emp.setEmpId(101);
					emp.setName("A");
					emp.setSalary(5000);
					emp.saveEmpDetails();
			case 1:emp.setEmpId(101);
					emp.setName("B");
					emp.setSalary(51000);
					emp.saveEmpDetails();
			case 2:emp.setEmpId(103);
					emp.setName("C");
					emp.setSalary(8000);
					emp.saveEmpDetails();
			case 3:emp.setEmpId(104);
					emp.setName("D");
					emp.setSalary(1000);
					emp.saveEmpDetails();
			case 4:emp.setEmpId(109);
					emp.setName("E");
					emp.setSalary(6000);
					emp.saveEmpDetails();
			case 5:emp.setEmpId(100);
					emp.setName("F");
					emp.setSalary(52000);
					emp.saveEmpDetails();
			case 6:emp.setEmpId(105);
					emp.setName("G");
					emp.setSalary(57000);
					emp.saveEmpDetails();
			case 7:emp.setEmpId(107);
					emp.setName("H");
					emp.setSalary(5090);
					emp.saveEmpDetails();
			case 8:emp.setEmpId(108);
					emp.setName("I");
					emp.setSalary(15000);
					emp.saveEmpDetails();
			case 9:emp.setEmpId(110);
					emp.setName("J");
					emp.setSalary(5000);
					emp.saveEmpDetails();
			}
		}
		
		
		//System.out.println(emp.ht);
		
		
		List<Integer> list = Arrays.asList(emp.getEmpId());
		//List<String> lists = Arrays.asList(name);
		TreeSet<Integer> ts = new TreeSet<Integer>(emp.ht.keySet());
		//TreeSet<String> tss = new TreeSet<String>(lists);
		System.out.println("Employee id sorted in Asending order with out duplicates are:");
		for(Integer n: ts) {
			//System.out.println(n);
			if(emp.ht.containsKey(n)) {
				System.out.println(n+" "+emp.ht.get(n));
			}
			else {
				System.out.println(emp.ht);
			}
		}
		
		//System.out.println("Employee id sorted in Decending order with out duplicates are:");
		/*for(String n: tss) {
			System.out.println(n);
		}*/
	}

}
