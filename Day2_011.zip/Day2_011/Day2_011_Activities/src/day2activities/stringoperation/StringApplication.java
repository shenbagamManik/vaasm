package day2activities.stringoperation;

public class StringApplication {
	String mainString;
	String temp;
	StringApplication(){
		mainString = "The quick brown fox jumps over the lazy dog";
	}
	void stringOperation() {
		System.out.println("MainString and Length of string\n"+mainString+":::"+mainString.length());
		//Finding the char at index
		System.out.println("Char at 12th index is:::\t"+mainString.charAt(11));
		//finding word in string
		if(mainString.contains("is")) 
		{
			System.out.println("Yes the word is present");
		}
		else {
			System.out.println("No the word is Not present");
		}
		//concatination
		String mainStringCon = mainString+" and killed it";
		System.out.println("The main statement changed to\n"+mainStringCon);
		//Check the end of statment
		if(mainString.endsWith("dogs")) {
			System.out.println("Statement is ends with dogs");
		}
		else {
			System.out.println("Statement is NOT ends with dogs");
		}
		
		//Compare the string for case sensitive
		String str1 = "The quick brown fox jumps over the lazy Dog";
		String str2 = "THE QUICK BROWN FOX JUMPS OVER THE LACY DOG";
		String str3 = "The quick brown Fox jumps over the lazy Dog";
		if(mainString.equals(str1)) {
			System.out.println("Statements Match");
		}
		else {
			for (int i = 0; i < mainString.length() && i < str1.length(); ++i) {
		        if (mainString.charAt(i) != str1.charAt(i)) {
		        	System.out.println("The statement differs at::\t"+mainString.charAt(i));
		        }
		    }
			
		}
		if(mainString.equals(str2)) {
						System.out.println("Statements Match");
		}
		else {
			
			System.out.println("No statements donot match because case sensitive Upper case letters hs different values");
		}
		if(mainString.equals(str3)) {
			System.out.println("Statements Match");
		}
		else {
			 for (int i = 0; i < mainString.length() && i < str3.length(); ++i) {
			        if (mainString.charAt(i) != str3.charAt(i)) {
			        	System.out.println("The statement differs at::\t"+mainString.charAt(i));
			        }
			    }
			   
			
		}
		
		//Replace the word
		System.out.println("****************** String Replace**************\t");
		mainString = mainString.replace("the","A");
		System.out.println("Replaced Statement is::\t"+mainString);
		
		//split string
		System.out.println("******************String Split**************\t");
		String[] splitString = mainString.split("s",2);
		System.out.println("First String::\t"+splitString[0]);
		System.out.println("Second String::\t"+splitString[1]);
		
		System.out.println("****************** Split Animal names**************\t");
		temp = mainString.substring(16,20);
		System.out.println("Fox from String::\t"+temp);
		temp = mainString.substring(38,41);		
		System.out.println("Dog from String::\t"+temp);
		
		//lower case and upper case
		mainString = mainString.toUpperCase();
		System.out.println("Converted to upper case:::\n"+mainString);
		
		mainString = mainString.toLowerCase();
		System.out.println("Converted to Lower case:::\n"+mainString);
		
		//index position
		
		System.out.println("Index of char a:::\t"+mainString.indexOf('a'));
		System.out.println("Last Index of char e:::\t"+mainString.lastIndexOf('e'));
		
	}

}
