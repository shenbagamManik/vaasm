package day2activities.stringoperation;

public class TestStringApplication {

	public static void main(String[] args) {
		StringApplication sa = new StringApplication();
		sa.stringOperation();
	}

}
