package day2activities.customerarray;

import day2activities.customer.Customer;

public class CustomerArray {
	
	long temp;

	public void sort(Customer[] cus) {
		 for (int i = 0; i < cus.length; i++) {
		      for (int j = i; j < cus.length; j++) {
		        if (cus[j].getAcNum() > cus[i].getAcNum()) 
		        {
		           temp = cus[j].getAcNum();
		           cus[j].setAcNum(cus[i].getAcNum());
		           cus[i].setAcNum(temp);
		        }
		      }
		    }
		 for(int i=0;i<cus.length;i++) {
			 System.out.println(cus[i].getAcNum());
			 System.out.println(cus[i].getCusName());
			 System.out.println(cus[i].getIniBalance());
		 }
		 
	}
	

}
