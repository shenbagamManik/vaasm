package day2activities.customerarray;

import day2activities.customer.Customer;

public class TestCustomerArray {

	public static void main(String[] args) {
		CustomerArray ca = new CustomerArray();
		Customer cus[] = new Customer[4];
		cus[0] = new Customer(1);
		cus[0].setAcNum(13);
		cus[0].setCusName("Shenbagam");
		cus[0].setIniBalance(100000);
		
		
		cus[1] = new Customer(2);
		cus[1].setAcNum(115);
		cus[1].setCusName("Shen");
		cus[1].setIniBalance(100000);
		
		cus[2] = new Customer(3);
		cus[2].setAcNum(1);
		cus[2].setCusName("Shenbag");
		cus[2].setIniBalance(100000);
		
		cus[3] = new Customer(4);
		cus[3].setAcNum(14);
		cus[3].setCusName("S");
		cus[3].setIniBalance(100000);
		
		
		ca.sort(cus);

	}

}
