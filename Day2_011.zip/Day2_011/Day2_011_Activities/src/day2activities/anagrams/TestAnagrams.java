package day2activities.anagrams;

public class TestAnagrams {

	public static void main(String[] args) {
		Anagrams ana = new Anagrams();
		ana.isAnagram("Ate","eat");
		ana.isAnagram("SchooL Master","The Class Room");
		ana.isAnagram("This","That");

	}

}
