package day2activities.anagrams;

import java.lang.reflect.Array;
import java.util.Arrays;

public class Anagrams {
	
	void isAnagram(String one,String two) {
		//truncate the white spaces
		
		String first = one.replaceAll("\\s","");
		String second = two.replaceAll("\\s","");
		
		boolean flag = true;
		
		if(first.length() != second.length()) {
			flag = false;
		}
		else {
			char[] str1 = first.toLowerCase().toCharArray();
			char[] str2 = second.toLowerCase().toCharArray();
			
			Arrays.sort(str1);
			Arrays.sort(str2);
			
			flag = Arrays.equals(str1,str2);
		}
		
		if(flag) {
			System.out.println(one +" and "+two+"\tThe two strings are Anagrams");			
		}
		else {
			System.out.println(one +" and "+two+"\tThe two strings are  Not Anagrams");	
		}
		
	}

}
