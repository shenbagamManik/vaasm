package day2activities.storeandretrieve;

import java.util.ArrayList;

public class StoreRetriveName {
			ArrayList<String> names;
			StoreRetriveName(){
				names = new ArrayList<String>();
			}
			void assignNames() {
				names.add("Shenbagam");
				names.add("Priya");
				names.add("Ramya");
				names.add("Jothi");
				names.add("Menaha");
				names.add("Punitha");
				names.add("Raju");
				names.add("Arun");
				names.add("Prashanth");
				names.add("Karthi");
			}
			void retriveNames() {
				for(int i=0;i<names.size();i++) {					
					System.out.println(names.get(i));
				}
			}
}
