package day2activities.storeandretrieve;

public class TestStoreRetriveName {

	public static void main(String[] args) {
		StoreRetriveName srn = new StoreRetriveName();
		srn.assignNames();
		srn.retriveNames();
	}

}
