package day2activities.customer;

import java.util.ArrayList;
import java.util.List;

public class TestCustomer {

	public static void main(String[] args) {       
		Customer cus = new Customer();	
		System.out.println("Account No::"+cus.acNum);
		cus.setCusName("Shenbagam");
		cus.setIniBalance(100000);			
		System.out.println(cus.getCusName());
		System.out.println(cus.getIniBalance());		
		
		Customer cus1 = new Customer();
		System.out.println("Account No::"+cus.acNum);
		cus1.setCusName("Priya");
		cus1.setIniBalance(200000);
		System.out.println(cus1.getCusName());
		System.out.println(cus1.getIniBalance());
		
		Customer cus2 = new Customer();
		System.out.println("Account No::"+cus.acNum);
		cus2.setCusName("Bhuvana");
		cus2.setIniBalance(400000);
		System.out.println(cus2.getCusName());
		System.out.println(cus2.getIniBalance());


	}

}
