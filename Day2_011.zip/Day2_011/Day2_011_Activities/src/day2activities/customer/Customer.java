package day2activities.customer;

import java.util.*;
import java.awt.List;

public class Customer {
	static long acNum = 100;
	static String cusName;
	static double iniBalance;
	
	
	public Customer(){
		
		//System.out.println("Account No::"+acNum);
		acNum++;
	}
public Customer(int no){
		
		//System.out.println("Account No::"+acNum);
	int  eno = no;
	
     
	}
	
	public long getAcNum() {
		return acNum;
	}
	public void setAcNum(long cusName) {
		this.acNum = cusName;
	}
	public String getCusName() {
		return cusName;
	}
	public void setCusName(String cusName) {
		this.cusName = cusName;
	}
	public double getIniBalance() {
		return iniBalance;
	}
	public void setIniBalance(double iniBalance) {
		this.iniBalance = iniBalance;
	}
	
}
