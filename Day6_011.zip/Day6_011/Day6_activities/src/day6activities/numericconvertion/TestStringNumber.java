package day6activities.numericconvertion;

public class TestStringNumber {

	public static void main(String[] args) {
		StringNumber sn = new StringNumber();
		sn.setNum("22,25,67,89,100");
		sn.convertNum();
	}

}
