package day6activities.numericconvertion;
import java.util.StringTokenizer;

public class StringNumber {
	String num;
	int sum;
	public String getNum() {
		return num;
	}
	public void setNum(String num) {
		this.num = num;
	}
	public int getSum() {
		return sum;
	}
	public void setSum(int sum) {
		this.sum = sum;
	}
	
	void convertNum(){
		StringTokenizer st = new StringTokenizer(num,",");
		while(st.hasMoreTokens()){
			sum = sum+Integer.parseInt(st.nextToken());
			
		}	
		System.out.println("Total of "+num+" is: "+sum);
	}
}
