package day6activities.numbers;

public class TestNumberValues {

	public static void main(String[] args) {
		MathFunctions nv = new MathFunctions();
		nv.setA(50);
		nv.valueOfVar();
		nv.cubePrimeNum();
	}

}
