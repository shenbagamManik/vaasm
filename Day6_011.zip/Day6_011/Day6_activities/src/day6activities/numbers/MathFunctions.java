package day6activities.numbers;

import java.util.StringTokenizer;

public class MathFunctions {
	double a;
	int b[];
	boolean isPrime;
	public double getA() {
		return a;
	}
	public void setA(double a) {
		this.a = a;
	}
	void valueOfVar(){
		System.out.println("Floor value of "+a+" is::"+Math.floor(a));
		System.out.println("Ceiling  value of "+b+" is::"+Math.floor(a));
	}
	void cubePrimeNum(){
		int n = 100;		
		String str = "";
		for(int i=0;i<=n;i++){
			int temp = 0;
			for(int j=i;j>=1;j--){
				if(i%j == 0){
					temp = temp+1;
				}
			}
			if(temp == 2){
				str = str+i+" ";
				/*System.out.print("Prime number::"+i+"\t");
				System.out.println("Cube root is"+Math.cbrt(i));*/
			}
		}
		System.out.println(str);
		StringTokenizer st = new StringTokenizer(str," ");
		while(st.hasMoreTokens()){
			int num = Integer.parseInt(st.nextToken());
			System.out.println("Cube root of "+num+" is: "+Math.cbrt(num));
		}
	}
}
