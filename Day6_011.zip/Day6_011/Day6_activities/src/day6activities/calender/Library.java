package day6activities.calender;

import java.util.Date;

public class Library {
String books;
String members;
Date dateIssue;
Date dateReturn;
Date nextMonthIssue;
String nextMonthReturn;
public Date getNextMonthIssue() {
	return nextMonthIssue;
}
public void setNextMonthIssue(Date nextMonthIssue) {
	this.nextMonthIssue = nextMonthIssue;
}
public String getNextMonthReturn() {
	return nextMonthReturn;
}
public void setNextMonthReturn(String nextMonthReturn) {
	this.nextMonthReturn = nextMonthReturn;
}
public String getBooks() {
	return books;
}
public void setBooks(String books) {
	this.books = books;
}
public String getMembers() {
	return members;
}
public void setMembers(String members) {
	this.members = members;
}
public Date getDateIssue() {
	return dateIssue;
}
public void setDateIssue(Date dateIssue) {
	this.dateIssue = dateIssue;
}
public Date getDateReturn() {
	return dateReturn;
}
public void setDateReturn(Date dateReturn) {
	this.dateReturn = dateReturn;
}



}
