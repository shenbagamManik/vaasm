package day6activities.calender;

import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class TestLibrary {

	public static void main(String[] args) throws Exception {
		Library lib = new Library();
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		Date issueDay = (Date) dateFormat.parse("05-07-2018");
		Date returnDay = (Date) dateFormat.parse("27-08-2018");
		lib.setBooks("ABC");
		lib.setMembers("Ram");
		lib.setDateIssue(issueDay);
		lib.setDateReturn(returnDay);
		
		
		BillCalculation billCalc = new BillCalculation(issueDay,returnDay);
		long bill = billCalc.billDisplay();
		int monthCount = billCalc.monthCount;
		//System.out.println("Month count"+monthCount);
		
		
			System.out.println("MemberName:"+lib.getMembers());
			System.out.println("Book rented"+lib.getBooks());
			System.out.println("Date of Issue"+lib.getDateIssue());
			System.out.println("Date of return"+billCalc.previousmonthCount);
			System.out.println("Bill Amt"+bill);
			
			System.out.println("MemberName:"+lib.getMembers());
			System.out.println("Book rented"+lib.getBooks());
			System.out.println("Date of Issue"+lib.getDateIssue());
			System.out.println("Date of return"+lib.getDateReturn());
			System.out.println("Bill Amt"+monthCount);
		
		
	}

}
