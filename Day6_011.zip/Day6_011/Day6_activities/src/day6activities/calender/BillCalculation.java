package day6activities.calender;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import java.util.GregorianCalendar;

public class BillCalculation extends Library{
	long fees;
	Date issueDate;
	Date returnDate;
	
	int returnMonth;
	static int monthCount;
	static String previousmonthCount;
	Date month;
	long bill;
	String newDateAssign;
	
	Date newDate;
	
	BillCalculation(Date issueDate,Date returnDate){
		this.issueDate = issueDate;
		this.returnDate = returnDate;
		
		this.returnMonth = returnDate.getMonth();
	}
	@SuppressWarnings("deprecation")
	long billDisplay() throws ParseException{
		Library lib = new Library();
		Calendar calen =Calendar.getInstance();	
		calen.setTime(issueDate);
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		
		
		
		int diffInDays = (int)((returnDate.getTime()-issueDate.getTime())/(1000*60*60*24));
		int diffInDaysMonth = diffInDays-31;
		int monthdays = diffInDays-diffInDaysMonth;
		//System.out.println("Number of days differ are:::"+diffInDays);
		if(diffInDays <= 7){
			fees = 100;
		}
		else if(diffInDays>7 && monthdays<=31 ){
			fees = 100+(31-7)*10;
			
			int returnDateDay = monthdays;
			int returnDateMonth = issueDate.getMonth();
			int returnDateYear = 2018;
			newDateAssign = (String) (returnDateDay+"-"+returnDateMonth+"-"+returnDateYear);
			//System.out.println("Previous month date:::"+newDateAssign);
			newDate = (Date) dateFormat.parse(newDateAssign);
			lib.setNextMonthReturn(newDateAssign);	
			previousmonthCount = newDateAssign;
		}
		 if(diffInDays>31){
			
			 monthCount = 100+diffInDaysMonth*50;
			
			//lib.setDateReturn(returnDate);
			 
			
		}
		return fees;
	}
	
	
	
}
