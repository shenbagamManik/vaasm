package day6activities.moviecelebration;

public class Movie {
	int numDayRun;

	public int getNumDayRun() {
		return numDayRun;
	}

	public void setNumDayRun(int numDayRun) {
		this.numDayRun = numDayRun;
	}
	void display(){
		if(numDayRun>25 && numDayRun<50){
			System.out.println("Silver Jubilee Film");
		}
		else if(numDayRun>=50 && numDayRun <60){
			System.out.println("Golden Jubilee Film");
		}
		else if(numDayRun>=60 && numDayRun <75){
			System.out.println("Diamond  Jubilee Film");
		}
		else if(numDayRun>=75){
			System.out.println("Platinum  Jubilee Film");
		}
	}
	
}
