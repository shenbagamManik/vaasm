package day6activities.moviecelebration;

public class TestMovie {
	public static void main(String args[]){
		Movie mo =new Movie();
		mo.setNumDayRun(56);
		mo.display();
	}
	
}
