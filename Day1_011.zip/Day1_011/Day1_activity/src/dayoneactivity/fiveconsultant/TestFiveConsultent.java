package dayoneactivity.fiveconsultant;

public class TestFiveConsultent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FiveConsultent fc = new FiveConsultent();
		fc.displayConsultent("Shenbagam","001", 300, 24, 5);
		fc.displayConsultent("Sangeetha", "002", 400,20, 8);
		fc.displayConsultent("Priya", "003", 500,22, 5);
		fc.displayConsultent("Bhuvana", "004", 600,25,8);
		fc.displayConsultent("Maha", "005", 400,20, 6);
	}

}
