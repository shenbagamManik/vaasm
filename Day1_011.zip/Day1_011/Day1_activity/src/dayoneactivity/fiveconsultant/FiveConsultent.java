package dayoneactivity.fiveconsultant;

import java.util.Scanner;

public class FiveConsultent {
	String Name;
	String Id;
	float perDaySalary;
	int noofDaysPresent;
	float tax;
	float grossSalary;
	float netSalary; 
	
	public void displayConsultent(String name,String id,float perDaySalary,int noofDaysPresent,float tax){
		
		Id = id;
		
		Name = name;
		
		this.perDaySalary = perDaySalary;
		
		this.noofDaysPresent = noofDaysPresent;
		
		this.tax = tax;
		grossSalary = perDaySalary*noofDaysPresent;
		
		netSalary = grossSalary-tax;
		System.out.println("ConsultentId::"+Id);
		System.out.println("ConsultentName::"+Name);
		System.out.println("ConsultentGrossSalary::"+grossSalary);
		System.out.println("ConsultentNetSalary::"+netSalary);
		
	}

	

}
