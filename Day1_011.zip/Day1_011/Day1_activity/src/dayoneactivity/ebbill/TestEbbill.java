package dayoneactivity.ebbill;

public class TestEbbill {
	public static void main(String args[]){
		EB_bill ebbill = new EB_bill();
	}
}
