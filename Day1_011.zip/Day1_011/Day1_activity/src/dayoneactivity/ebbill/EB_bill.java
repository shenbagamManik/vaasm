package dayoneactivity.ebbill;
import java.util.Scanner;
public class EB_bill {
	EB_bill(){
	System.out.println("Enter the Units");
	Scanner sc=new Scanner(System.in);
	int unit = sc.nextInt();
	int amount = 0;
	System.out.println("The number is::"+unit);
	
	if(unit <= 100){
		amount = unit*1;
	}
	else if(unit >100 && unit <=200){
		
		int temp1 = unit - 100;
		amount = temp1*2+100;
	}
	else if(unit >200 && unit <=300){
		int temp1 = unit-100;
		int temp2 = temp1-100;
		
		amount = 100+temp2*3+100*2;
		
	}
	else if(unit>300){
		int temp1 = unit-100;
		int temp2 = temp1-100;
		int temp3 = temp2-100;
		amount = 100+temp3*5+100*2+100*3;
	}
	System.out.println("Bill amout is::"+amount);
	}

}
