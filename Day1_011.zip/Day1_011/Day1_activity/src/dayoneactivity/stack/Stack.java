package dayoneactivity.stack;

public class Stack {
	static int index;
	final int a[];
	
	Stack(){		
		index = 0;
		a = new int[10];
	}
	public void pop() {		
		
		System.out.println(a[index]);
		index--;
		
	}
	public void push(int value) {
		a[index] = value;
		index++;
		//System.out.print(a[value]);
	}
	public int display() {
		return 0;
	}	
	
	
}
