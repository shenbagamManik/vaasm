package dayoneactivity.eggcount;

public class TestEggcount {
	public static void main(String args[]){	
		EggCount e = new EggCount();
		e.countEggs();
	}
}
