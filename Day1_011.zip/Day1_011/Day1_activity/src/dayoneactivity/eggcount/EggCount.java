package dayoneactivity.eggcount;
import java.util.Scanner;
public class EggCount{
	int eggCount;
	EggCount(){
		eggCount = 1150;	
	}
	public void countEggs(){
	/*System.out.println("Enter the number of eggs::");
	Scanner sc=new Scanner(System.in);*/
		int num = eggCount;
		int gross = num/144;
		int dozentot = num%144;
		int dozen = dozentot/12;
		int remain = dozentot%12;
	
		System.out.println("Gross Eggs::"+gross);
		System.out.println("Dozen Eggs::"+dozen);
		System.out.println("Remaining Eggs::"+remain);
	}

}
