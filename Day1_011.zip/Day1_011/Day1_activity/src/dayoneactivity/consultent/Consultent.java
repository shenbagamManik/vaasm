package dayoneactivity.consultent;
import java.util.Scanner;

public class Consultent {
	String empName;
	String empId;
	float perDaySalary;
	int noofDaysPresent;
	
	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName){
		this.empName = empName;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public float getPerDaySalary() {
		return perDaySalary;
	}

	public void setPerDaySalary(float perDaySalary) {
		this.perDaySalary = perDaySalary;
	}

	public int getNoofDaysPresent() {
		return noofDaysPresent;
	}

	public void setNoofDaysPresent(int noofDaysPresent) {
		this.noofDaysPresent = noofDaysPresent;
	}
	
	public float getGrossSalary() {
		perDaySalary = getPerDaySalary();
		
		noofDaysPresent = getNoofDaysPresent();		
		
		grossSalary = (int) (perDaySalary*noofDaysPresent);
		
		return grossSalary;
	}
	public float getNetSalary() {
		perDaySalary = getPerDaySalary();
		
		noofDaysPresent = getNoofDaysPresent();		
		tax = getTax()/100;
		netSalary = (int) (grossSalary-tax);
		
		return netSalary;
	}

	public float getTax() {
		return tax;
	}

	public void setTax(float tax) {
		this.tax = tax;
	}

	float tax;
	float grossSalary;
	float netSalary; 
	
	Consultent(){			
		empId = getEmpId();		
		empName = getEmpName();
		
		perDaySalary = getPerDaySalary();
		
		noofDaysPresent = getNoofDaysPresent();
		
		
		
		
	}
	
	
	

}
