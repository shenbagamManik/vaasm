package dayoneactivity.consultent;

public class TestConsultent {
	public static void main(String args[]){
		Consultent cons = new Consultent();
		cons.setEmpId("001");
		cons.setEmpName("Shenbagam");
		cons.setNoofDaysPresent(25);
		cons.setPerDaySalary(500);
		cons.setTax(8);
		
		System.out.println("EmpId::"+cons.getEmpId());
		System.out.println("EmpName::"+cons.getEmpName());
		System.out.println("EmpGrossSalary::"+cons.getGrossSalary());
		System.out.println("EmpNetSalary::"+cons.getNetSalary());
	}
}
