package org.vaasm.bookshop.dao;

import org.vaasm.bookshop.entity.Account;

public interface AccountDAO {
 
    
    public Account findAccount(String userName );
    
}