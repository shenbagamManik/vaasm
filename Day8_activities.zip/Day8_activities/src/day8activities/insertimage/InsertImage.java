/*CREATE TABLE Trainee
( trainee_id number(10) NOT NULL,  
  trainee_name varchar2(50) NOT NULL, 
  phone_num varchar2(50) NOT NULL, 
 trainee_img BLOB,
  PRIMARY KEY (trainee_id)  
);  
*/

package day8activities.insertimage;
import java.sql.*;  
import java.io.*;  
public class InsertImage {
	public static int traineeID = 105;
	Connection con;
	InsertImage(){
		traineeID++;
	}
	void insetTrainee(int empNum,String empName,String phoneNo,String image) throws ClassNotFoundException, SQLException, IOException {
		try {
			getConnection();         
			PreparedStatement ps=con.prepareStatement("insert into trainee values(?,?,?,?)");
				ps.setInt(1,empNum);
				ps.setString(2, empName);
				ps.setString(3,phoneNo);
			FileInputStream fin= new FileInputStream(image);  
		
				ps.setBinaryStream(4,fin,fin.available());  
			int i=ps.executeUpdate();  
				System.out.println(i+" records affected");  
			con.close();  
		}catch(FileNotFoundException e) {
			System.out.println(e);
		}
	}
	
	public void updateImage(int empId,String image) throws SQLException, IOException {
		getConnection();
		PreparedStatement ps = con.prepareStatement("UPDATE Trainee SET trainee_img = ? WHERE trainee_id = ?");
		
		FileInputStream fin= new FileInputStream(image);  		
		ps.setBinaryStream(1,fin,fin.available());
		ps.setInt(2,empId);
		int i=ps.executeUpdate(); 
		System.out.println(" records affected"); 
	}
	public void getConnection() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:orashen/shen123@VAASM:1521:XE"); 
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
			
	}
	
	
}
		 
	
