package day8activities.insertimage;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

public class TestInsertImage {
	public static void main(String args[]) throws ClassNotFoundException, SQLException, IOException {
		InsertImage inimg = new InsertImage();		
		Scanner s = new Scanner(System.in);
		
		inimg.insetTrainee(101,"Shenbagam","9884472620","C:\\\\Users\\\\vaasm\\\\HCL-Shenbagam\\\\Day8_activities\\\\src\\\\image\\\\book_background_1.jpg");
		//inimg.insetTrainee(102,"ManiMegala","9884472621","C:\\\\Users\\\\vaasm\\\\HCL-Shenbagam\\\\Day8_activities\\\\src\\\\image\\\\book_background_1.jpg");
		
		inimg.updateImage(101,"C:\\Users\\vaasm\\HCL-Shenbagam\\Day8_activities\\src\\image\\enter_arrow.png");
	
	}
	
}
