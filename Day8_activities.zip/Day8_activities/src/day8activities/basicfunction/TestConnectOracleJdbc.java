package day8activities.basicfunction;

import java.sql.SQLException;
import java.util.Scanner;

public class TestConnectOracleJdbc {

	public static void main(String[] args) throws SQLException {
		ConnectOracleJdbc  coj = new ConnectOracleJdbc();
		coj.getConnection();
		System.out.println("Which user operatiopn to be done!\n1.Insert\n2.update\n3.search\n4.delete");
		Scanner s = new Scanner(System.in);
		int operation = Integer.parseInt(s.nextLine());
		switch(operation) {
			case 1:coj.insert();
				break;
			case 2:coj.update();
				break;
			case 3:coj.search();
				break;
			case 4:coj.delete();
				break;
			default:System.out.println("Please type 1 - 4 numbers only");
			break;
		
		}
		

	}

}
