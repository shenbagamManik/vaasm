/*CREATE TABLE Training
( trainee_id number(10) NOT NULL,  
  trainee_name varchar2(50) NOT NULL,  
  city varchar2(50),  
  CONSTRAINT trainee_pk PRIMARY KEY (trainee_id)  
);  
*/
package day8activities.basicfunction;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class ConnectOracleJdbc {
	    
	    static Connection getConnection() {
			Connection dbConnection = null;
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");				
			} catch (ClassNotFoundException e) {
				System.out.println(e.getMessage());
			}

			try {				
				dbConnection = DriverManager.getConnection("jdbc:oracle:thin:orashen/shen123@VAASM:1521:XE");				
				return dbConnection;
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
			return dbConnection;			
		}

		public void insert() throws SQLException{
			Connection dbConnection = null;
			Statement statement = null;
			String insertTableSQL = "INSERT INTO Training(trainee_id, trainee_name, city) VALUES(51, 'Shenbagam','chennai')";
			String insertTableSQL1 = "INSERT INTO Training(trainee_id, trainee_name, city) VALUES(52, 'Shenbagam','chennai')";				
			
			try {
				dbConnection = getConnection();
				statement = dbConnection.createStatement();
				System.out.println(insertTableSQL);				
				statement.executeUpdate(insertTableSQL);
				/*statement.executeUpdate(insertTableSQL1);
				statement.executeUpdate(insertTableSQL2);*/
				System.out.println("Record is inserted into  table!");
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			} finally {
				if (statement != null) {
					statement.close();
				}
				if (dbConnection != null) {
					dbConnection.close();
				}

			}
			
		}

		public void update() throws SQLException {
			Connection dbConnection = null;
			Statement statement = null;

			String updateTableSQL = "UPDATE Training SET trainee_name ='Shen' WHERE trainee_id = 51";

			try {
				dbConnection = getConnection();
				statement = dbConnection.createStatement();

				System.out.println(updateTableSQL);

				// execute insert SQL stetement
				statement.executeUpdate(updateTableSQL);
				

				System.out.println("Record is updated successfully!");

			} catch (SQLException e) {

				System.out.println(e.getMessage());

			} finally {

				if (statement != null) {
					statement.close();
				}

				if (dbConnection != null) {
					dbConnection.close();
				}
			}			
		}

		public void search() throws SQLException {
			Connection dbConnection = null;
			Statement statement = null;
			ResultSet rs = null;
			String selectTableSQL = "SELECT city FROM Training  WHERE  trainee_name = 'Shenbagam'";		
			
			try {
				dbConnection = getConnection();
				statement = dbConnection.createStatement();
				System.out.println(selectTableSQL );				
				rs=statement.executeQuery(selectTableSQL);
				while(rs.next()) {
	                System.out.print(rs.getString("city") + "\t");
	              
	            }

			} catch (SQLException e) {

				System.out.println(e.getMessage());

			} finally {

				if (statement != null) {
					statement.close();
				}

				if (dbConnection != null) {
					dbConnection.close();
				}

			}
			
			
		}

		public void delete() throws SQLException {
			Connection dbConnection = null;
			Statement statement = null;

			String deleteTableSQL = "DELETE FROM Training WHERE trainee_name = 'Shenbagam'";
			

			try {
				dbConnection = getConnection();
				statement = dbConnection.createStatement();

				System.out.println(deleteTableSQL);

				// execute insert SQL stetement
				statement.executeUpdate(deleteTableSQL);				
				System.out.println("Record is inserted into DBUSER table!");

			} catch (SQLException e) {

				System.out.println(e.getMessage());

			} finally {

				if (statement != null) {
					statement.close();
				}

				if (dbConnection != null) {
					dbConnection.close();
				}

			}
			
			
		}
	
}
