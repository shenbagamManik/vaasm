/*
 * ***************************Stored procedure for updating the salary****************
 * CREATE OR REPLACE PROCEDURE updateEmployeeByEmpId(
	   p_empid IN EMPLOYEE.EMP_ID%TYPE,	   
	   o_salary IN  EMPLOYEE.SALARY%TYPE
	  )
IS
BEGIN
  UPDATE Employee SET salary =  o_salary WHERE emp_id = p_empid ;
END;
/
*/

package day8activities.callablestatements;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class CallableStatements {
	public void updateSalary() throws SQLException, ClassNotFoundException{
		callOracleStoredProcOUTParameter();
	}
	private static void callOracleStoredProcOUTParameter() throws ClassNotFoundException {
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:orashen/shen123@VAASM:1521:XE");
			String updateSql = "{call updateEmployeeByEmpId(?,?)}";
			CallableStatement callableStatement = conn.prepareCall(updateSql);
				callableStatement.setInt(1, 104);
				callableStatement.setInt(2, 2000);
				callableStatement.executeUpdate();
			System.out.println("udated the value successfully");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
