package day8activities.callablestatements;

import java.sql.SQLException;


public class TestCallableStatements {
	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		CallableStatements cstat = new CallableStatements();
		cstat.updateSalary();

		
	}
}
